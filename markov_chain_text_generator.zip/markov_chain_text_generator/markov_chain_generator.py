import random

class MarkovChainTextGenerator:
    def __init__(self):
        self.markov_chain = {}

    def train(self, text, n=2):
        words = text.split()
        for i in range(len(words) - n):
            prefix = tuple(words[i:i+n-1])
            next_word = words[i+n-1]
            if prefix not in self.markov_chain:
                self.markov_chain[prefix] = []
            self.markov_chain[prefix].append(next_word)

    def generate(self, length=50):
        if not self.markov_chain:
            return "Model is empty. Train it first."

        prefix = random.choice(list(self.markov_chain.keys()))
        result = list(prefix)

        for _ in range(length - len(prefix)):
            next_words = self.markov_chain.get(prefix)
            if not next_words:
                break
            next_word = random.choice(next_words)
            result.append(next_word)
            prefix = tuple(result[-(len(prefix)):])

        return ' '.join(result)

if __name__ == "__main__":
    sample_text = """
    Machine learning is a method of data analysis that automates analytical model building.
    Using algorithms that iteratively learn from data, machine learning allows computers to find hidden insights without being explicitly programmed.
    """

    generator = MarkovChainTextGenerator()
    generator.train(sample_text, n=2)
    generated_text = generator.generate(30)
    print("Generated Text:\n", generated_text)
