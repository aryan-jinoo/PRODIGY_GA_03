# Markov Chain Text Generator

This is a simple Python implementation of a text generator using Markov Chains.

## Features
- Trains on sample text using bigrams (2-grams)
- Generates new random text based on word probabilities

## Usage

```bash
python markov_chain_generator.py
```

## Example Output
```
Generated Text:
machine learning allows computers to find hidden insights without being explicitly programmed using algorithms that iteratively learn from data machine
```
